//Create variables here
var dog,happydog,dogImg
var database 
var foodS,foodStock
var feed,addFood
var fedTime,lastfed
var milk

function preload()
{
	//load images here
  happydog=loadImage("images/dogImg.png")
  dogImg=loadImage("images/dogImg1.png")
}

function setup() {
  database=firebase.database();
	createCanvas(1000,500);
  milk=new Food()
  feed=createButton("Feed the dog")
  feed.position(50,80)
  feed.mousePressed(feedDog)

  addFood=createButton("Add Food")
  addFood.position(150,80)
  addFood.mousePressed(addFoods)

  dog=createSprite(800,300,10,10)
  dog.addImage(happydog)
  dog.scale=0.4
  foodStock=database.ref('Food')
  foodStock.on("value",readStock)
  foodStock.set(0)
}


function draw() {  
background(46,139,87)

milk.display()

  textSize(20)
  fill(255)
  text("Food Remaining:"+foodS,400,100)


  textStyle(BOLD)
  fill("black")
  text("Virtual Pet-2",410,50)

  fill(255,255,254)
  textSize(15)
  if(lastfed>=12){
    text("Last Feed: "+lastfed%12+"PM",410,80)
  }else if(lastfed==0){
    text("Last Feed: "+lastfed+"AM",410,80)
  }else{
    text("Last Feed: "+lastfed+ "AM",410,80)
  }


fedTime=database.ref('FeedTime')
fedTime.on("value",function(data){
  lastfed=data.val()
})




  drawSprites();
  
}

function readStock(data){
  foodS=data.val()
  milk.updateFoodStock(foodS)
}


function feedDog(){
  dog.addImage(dogImg);
  
  milk.updateFoodStock(milk.getFoodStock()-1)
  database.ref('/').update({
    Food:milk.getFoodStock(),
    FeedTime:hour()
  })
}

function addFoods(){
  foodS++
  dog.addImage(happydog)
  database.ref('/').update({
    Food:foodS
  })
}